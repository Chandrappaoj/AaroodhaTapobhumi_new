<?php
/**
 * Admin Trustees Management
 * POST /api/admin/trustees.php - Create trustee
 * PUT /api/admin/trustees.php?id=X - Update trustee
 * DELETE /api/admin/trustees.php?id=X - Delete trustee
 */

require_once '../config.php';

// Check authentication
checkAdminAuth();

$conn = getDBConnection();

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // CREATE TRUSTEE
        $input = json_decode(file_get_contents('php://input'), true);
        
        validateRequired($input, ['name', 'role']);
        
        $stmt = $conn->prepare("
            INSERT INTO trustees (name, role, description, image_url, display_order)
            VALUES (:name, :role, :description, :image, :display_order)
        ");
        
        $stmt->execute([
            'name' => sanitizeInput($input['name']),
            'role' => sanitizeInput($input['role']),
            'description' => isset($input['description']) ? sanitizeInput($input['description']) : null,
            'image' => isset($input['image_url']) ? sanitizeInput($input['image_url']) : null,
            'display_order' => isset($input['display_order']) ? (int)$input['display_order'] : 0
        ]);
        
        sendResponse(['success' => true, 'message' => 'Trustee created successfully', 'id' => $conn->lastInsertId()]);
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        // UPDATE TRUSTEE
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id === 0) sendError('Trustee ID required', 400);
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        $stmt = $conn->prepare("
            UPDATE trustees
            SET name = :name, role = :role, description = :description,
                image_url = :image, display_order = :display_order
            WHERE id = :id
        ");
        
        $stmt->execute([
            'id' => $id,
            'name' => sanitizeInput($input['name']),
            'role' => sanitizeInput($input['role']),
            'description' => isset($input['description']) ? sanitizeInput($input['description']) : null,
            'image' => isset($input['image_url']) ? sanitizeInput($input['image_url']) : null,
            'display_order' => isset($input['display_order']) ? (int)$input['display_order'] : 0
        ]);
        
        sendResponse(['success' => true, 'message' => 'Trustee updated successfully']);
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        // DELETE TRUSTEE
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id === 0) sendError('Trustee ID required', 400);
        
        $stmt = $conn->prepare("DELETE FROM trustees WHERE id = :id");
        $stmt->execute(['id' => $id]);
        
        sendResponse(['success' => true, 'message' => 'Trustee deleted successfully']);
        
    } else {
        sendError('Method not allowed', 405);
    }
    
} catch(PDOException $e) {
    error_log("Admin Trustees Error: " . $e->getMessage());
    sendError('Operation failed', 500);
}
?>
