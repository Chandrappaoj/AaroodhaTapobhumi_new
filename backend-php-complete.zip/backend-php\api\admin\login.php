<?php
/**
 * Admin Login
 * POST /api/admin/login.php
 */

require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 405);
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    validateRequired($input, ['username', 'password']);
    
    $username = sanitizeInput($input['username']);
    $password = $input['password'];
    
    $conn = getDBConnection();
    
    // Fetch admin user
    $stmt = $conn->prepare("
        SELECT id, username, password_hash
        FROM admin_users
        WHERE username = :username
    ");
    
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch();
    
    if (!$user || !password_verify($password, $user['password_hash'])) {
        sendError('Invalid username or password', 401);
    }
    
    // Start session
    session_start();
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_id'] = $user['id'];
    $_SESSION['admin_username'] = $user['username'];
    $_SESSION['last_activity'] = time();
    
    sendResponse([
        'success' => true,
        'message' => 'Login successful',
        'username' => $user['username']
    ]);
    
} catch(PDOException $e) {
    error_log("Admin Login Error: " . $e->getMessage());
    sendError('Login failed', 500);
}
?>
