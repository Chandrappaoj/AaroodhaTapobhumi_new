<?php
/**
 * Gallery API
 * GET /api/gallery.php?category=all|ashrama|events|seva|festivals
 */

require_once 'config.php';

try {
    $conn = getDBConnection();
    
    // Get query parameter
    $category = isset($_GET['category']) ? $_GET['category'] : 'all';
    
    if ($category === 'all') {
        // Fetch all images
        $stmt = $conn->prepare("
            SELECT id, image_url, alt_text, category
            FROM gallery
            ORDER BY uploaded_at DESC
        ");
        $stmt->execute();
    } else {
        // Fetch images by category
        $stmt = $conn->prepare("
            SELECT id, image_url, alt_text, category
            FROM gallery
            WHERE category = :category
            ORDER BY uploaded_at DESC
        ");
        $stmt->execute(['category' => $category]);
    }
    
    $images = $stmt->fetchAll();
    
    sendResponse(['images' => $images]);
    
} catch(PDOException $e) {
    error_log("Gallery API Error: " . $e->getMessage());
    sendError('Failed to fetch gallery images', 500);
}
?>
