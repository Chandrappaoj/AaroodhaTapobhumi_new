<?php
/**
 * Trustees API
 * GET /api/trustees.php
 */

require_once 'config.php';

try {
    $conn = getDBConnection();
    
    // Fetch all trustees ordered by display_order
    $stmt = $conn->prepare("
        SELECT id, name, role, description, image_url
        FROM trustees
        ORDER BY display_order ASC
    ");
    
    $stmt->execute();
    $trustees = $stmt->fetchAll();
    
    sendResponse(['trustees' => $trustees]);
    
} catch(PDOException $e) {
    error_log("Trustees API Error: " . $e->getMessage());
    sendError('Failed to fetch trustees', 500);
}
?>
