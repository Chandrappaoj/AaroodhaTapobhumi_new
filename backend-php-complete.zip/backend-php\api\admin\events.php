<?php
/**
 * Admin Events Management
 * POST /api/admin/events.php - Create event
 * PUT /api/admin/events.php?id=X - Update event
 * DELETE /api/admin/events.php?id=X - Delete event
 */

require_once '../config.php';

// Check authentication
checkAdminAuth();

$conn = getDBConnection();

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // CREATE EVENT
        $input = json_decode(file_get_contents('php://input'), true);
        
        validateRequired($input, ['title', 'date']);
        
        $stmt = $conn->prepare("
            INSERT INTO events (title, title_kannada, date, time, location, description, image_url, is_past)
            VALUES (:title, :title_kn, :date, :time, :location, :description, :image, :is_past)
        ");
        
        $stmt->execute([
            'title' => sanitizeInput($input['title']),
            'title_kn' => isset($input['title_kannada']) ? sanitizeInput($input['title_kannada']) : null,
            'date' => $input['date'],
            'time' => isset($input['time']) ? sanitizeInput($input['time']) : null,
            'location' => isset($input['location']) ? sanitizeInput($input['location']) : null,
            'description' => isset($input['description']) ? sanitizeInput($input['description']) : null,
            'image' => isset($input['image_url']) ? sanitizeInput($input['image_url']) : null,
            'is_past' => isset($input['is_past']) ? (int)$input['is_past'] : 0
        ]);
        
        sendResponse(['success' => true, 'message' => 'Event created successfully', 'id' => $conn->lastInsertId()]);
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        // UPDATE EVENT
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id === 0) sendError('Event ID required', 400);
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        $stmt = $conn->prepare("
            UPDATE events
            SET title = :title, title_kannada = :title_kn, date = :date, time = :time,
                location = :location, description = :description, image_url = :image, is_past = :is_past
            WHERE id = :id
        ");
        
        $stmt->execute([
            'id' => $id,
            'title' => sanitizeInput($input['title']),
            'title_kn' => isset($input['title_kannada']) ? sanitizeInput($input['title_kannada']) : null,
            'date' => $input['date'],
            'time' => isset($input['time']) ? sanitizeInput($input['time']) : null,
            'location' => isset($input['location']) ? sanitizeInput($input['location']) : null,
            'description' => isset($input['description']) ? sanitizeInput($input['description']) : null,
            'image' => isset($input['image_url']) ? sanitizeInput($input['image_url']) : null,
            'is_past' => isset($input['is_past']) ? (int)$input['is_past'] : 0
        ]);
        
        sendResponse(['success' => true, 'message' => 'Event updated successfully']);
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        // DELETE EVENT
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id === 0) sendError('Event ID required', 400);
        
        $stmt = $conn->prepare("DELETE FROM events WHERE id = :id");
        $stmt->execute(['id' => $id]);
        
        sendResponse(['success' => true, 'message' => 'Event deleted successfully']);
        
    } else {
        sendError('Method not allowed', 405);
    }
    
} catch(PDOException $e) {
    error_log("Admin Events Error: " . $e->getMessage());
    sendError('Operation failed', 500);
}
?>
