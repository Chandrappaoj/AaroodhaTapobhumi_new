<?php
/**
 * Admin Image Upload
 * POST /api/admin/upload.php
 */

require_once '../config.php';

// Check authentication
checkAdminAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 405);
}

try {
    if (!isset($_FILES['image'])) {
        sendError('No image file provided', 400);
    }
    
    $result = uploadImage($_FILES['image'], '../../uploads/');
    
    if ($result['success']) {
        sendResponse([
            'success' => true,
            'url' => $result['url'],
            'message' => 'Image uploaded successfully'
        ]);
    } else {
        sendError($result['error'], 400);
    }
    
} catch(Exception $e) {
    error_log("Image Upload Error: " . $e->getMessage());
    sendError('Upload failed', 500);
}
?>
