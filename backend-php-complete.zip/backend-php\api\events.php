<?php
/**
 * Events API
 * GET /api/events.php?type=upcoming|past
 */

require_once 'config.php';

try {
    $conn = getDBConnection();
    
    // Get query parameter
    $type = isset($_GET['type']) ? $_GET['type'] : 'upcoming';
    
    if ($type === 'upcoming') {
        // Fetch upcoming events
        $stmt = $conn->prepare("
            SELECT id, title, title_kannada, date, time, location, description, image_url
            FROM events
            WHERE is_past = 0 AND date >= CURDATE()
            ORDER BY date ASC
        ");
    } else {
        // Fetch past events
        $stmt = $conn->prepare("
            SELECT id, title, title_kannada, date, time, location, description, image_url
            FROM events
            WHERE is_past = 1 OR date < CURDATE()
            ORDER BY date DESC
            LIMIT 10
        ");
    }
    
    $stmt->execute();
    $events = $stmt->fetchAll();
    
    sendResponse(['events' => $events]);
    
} catch(PDOException $e) {
    error_log("Events API Error: " . $e->getMessage());
    sendError('Failed to fetch events', 500);
}
?>
